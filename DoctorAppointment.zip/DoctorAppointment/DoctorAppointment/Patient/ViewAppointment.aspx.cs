﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace DoctorAppointment.Patient
{
    public partial class ViewAppointment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblUser.Text = HttpContext.Current.User.Identity.Name;
        }

        protected void grdvwAppointment_SelectedIndexChanged(object sender, EventArgs e)
        {
                GridViewRow row = grdvwAppointment.SelectedRow;
                txtbxDate.Text = row.Cells[3].Text.ToString();
                txtbxId.Text = row.Cells[5].Text.ToString();

                btnCancel.Visible = true; 
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to cancel the appointment?", "Message from the web", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                dtsrcAppointment.Update();
                MessageBox.Show("Your appointment was successfully canceled.", "Message from the web", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                //do nothing
            }
        }
    }
}