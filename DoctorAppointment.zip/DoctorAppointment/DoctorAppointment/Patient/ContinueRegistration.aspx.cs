﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace DoctorAppointment.Patient
{
    public partial class ContinueRegistration : System.Web.UI.Page
    {
        public static string email;
        protected void Page_Load(object sender, EventArgs e)
        {
            email = HttpContext.Current.User.Identity.Name;
            Pat pat = new Pat(txtbxIdNo.Text, txtbxFname.Text, txtbxLname.Text, RadioButtonListGender.SelectedValue, txtbxAge.Text, txtbxCell.Text, email, drpdwnArea.SelectedValue);
            txtbxEmail.Text = email;
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            btnRegister.Text = "Adding Details...";
            email = HttpContext.Current.User.Identity.Name;
            Pat pat = new Pat(txtbxIdNo.Text, txtbxFname.Text, txtbxLname.Text, RadioButtonListGender.SelectedValue, txtbxAge.Text, txtbxCell.Text, email, drpdwnArea.SelectedValue);
            MessageBox.Show(Connection.AddPatient(pat), "Message from the web", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Response.Redirect("~/Patient/PatientHome.aspx");
        }

        protected void txtbxIdNo_TextChanged(object sender, EventArgs e)
        {

            if (Convert.ToInt32(txtbxIdNo.Text.Substring(6, 1)) < 5)
            {
                RadioButtonListGender.SelectedIndex = 0;
            }
            else if (Convert.ToInt32(txtbxIdNo.Text.Substring(6, 1)) > 4)
            {
                RadioButtonListGender.SelectedIndex = 1;
            }
            int curDate = 2021;
            string num = "19";
            string combine = num + txtbxIdNo.Text.Substring(0, 2);
            int age = curDate - Convert.ToInt32(combine);
            txtbxAge.Text = age.ToString();

            //int now = int.Parse(DateTime.Now.ToString("yyyy"));
            //txtbxAge.Text = String.Format("{0:yyyy}", txtbxIdNo.Text.Substring(0, 2));
        }
    }
}