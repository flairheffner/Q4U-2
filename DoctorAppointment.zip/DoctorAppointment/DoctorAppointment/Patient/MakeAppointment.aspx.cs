﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using System.Data.Odbc;
using System.Configuration;

namespace DoctorAppointment.Patient
{
    public partial class MakeAppointment : System.Web.UI.Page
    {
        string email;
        string patid;
        private static OdbcConnection conn;
        private static OdbcCommand commd;
        private static OdbcCommand com;
        string connectionString = ConfigurationManager.ConnectionStrings["appointmentdbConnectionString"].ToString();
        protected void Page_Load(object sender, EventArgs e)
        {
           email = HttpContext.Current.User.Identity.Name;
        }

        protected void drpdwnProvince_SelectedIndexChanged(object sender, EventArgs e)
        {
            pnlDoctor.Visible = true;
        }

        protected void clndrDate_SelectionChanged(object sender, EventArgs e)
        {
            DateTime currDate = DateTime.Now;
            if (clndrDate.SelectedDate < currDate)
            {
                MessageBox.Show("You cannot book for a passed date", "Message from the web", MessageBoxButtons.OK, MessageBoxIcon.Error);
                clndrDate.SelectedDate = currDate;
            }
            else if (clndrDate.SelectedDate == currDate)
            {
                MessageBox.Show("You cannot book for the same day", "Message from the web", MessageBoxButtons.OK, MessageBoxIcon.Information);
                clndrDate.SelectedDate = currDate;
            }
        }

        protected void grdvwDoctor_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblFname.Visible = true;
            lblId.Visible = true;
            lblSpec.Visible = true;
            txtbxFname.Visible = true;
            txtbxId.Visible = true;
            txtbxSpec.Visible = true;
            GridViewRow row = grdvwDoctor.SelectedRow;
            txtbxFname.Text = row.Cells[2].Text.ToString();
            txtbxId.Text = row.Cells[1].Text.ToString();
            txtbxSpec.Text = row.Cells[7].Text.ToString();
        }

        protected void btnBook_Click(object sender, EventArgs e)
        {
             conn = new OdbcConnection(connectionString);
            commd = new OdbcCommand("", conn);
            com = new OdbcCommand("", conn);
            try
            {
                conn.Open();
                string query = string.Format("SELECT patient_id FROM tblpatient WHERE email = '{0}'", email);
                commd.CommandText = query;
                OdbcDataReader readr = commd.ExecuteReader();
                
                while (readr.Read())
                {
                    patid = readr[0].ToString();
                    string query1 = string.Format("INSERT INTO appointment (health_issue, preferred_time, doc_speciality, date, patient_id, doc_id, appointment_status) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}')", drpdwnIssues.SelectedValue, drpdwnTime.SelectedValue, txtbxSpec.Text, clndrDate.SelectedDate, patid, txtbxId.Text, "Submitted");
                    com.CommandText = query1;
                    com.ExecuteScalar();
                }

              
                
                MessageBox.Show("Your appointment was successfully submitted.", "Message from the web", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                conn.Close();
            }
        }
    }
}