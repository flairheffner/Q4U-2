﻿using System.Web.UI;

namespace DoctorAppointment.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}