﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DoctorAppointment
{
    public class Pat
    {
        public string PantientID { get; set; }
        public string Fname { get; set; }
        public string Lname { get; set; }
        public string Gender { get; set; }
        public string Age { get; set; }
        public string Contact { get; set; }
        public string Email { get; set; }
        public string Area { get; set; }

        public Pat(string pantientid, string fname, string lname, string gender, string age, string contact, string email, string area)
        {
            PantientID = pantientid;
            Fname = fname;
            Lname = lname;
            Gender = gender;
            Age = age;
            Contact = contact;
            Email = email;
            Area = area;
        }
    }
}