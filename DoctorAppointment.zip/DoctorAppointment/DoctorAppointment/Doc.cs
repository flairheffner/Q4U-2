﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DoctorAppointment
{
    public class Doc
    {
        public string DocId { get; set; }
        public string Fname { get; set; }
        public string Lname { get; set; }
        public string Gender { get; set; }
        public string Contact { get; set; }
        public string Email { get; set; }
        public string Speciality { get; set; }

        public Doc(string docid, string fname, string lname, string gender, string contact, string email, string speciality)
        {
            DocId = docid;
            Fname = fname;
            Lname = lname;
            Gender = gender;
            Contact = contact;
            Email = email;
            Speciality = speciality;
        }
    }
}