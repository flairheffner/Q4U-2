﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Odbc;
using System.Configuration;


namespace DoctorAppointment
{
    public class Connection
    {
        private static OdbcConnection conn;
        private static OdbcCommand commd;
        private static OdbcCommand commd2;

        static Connection()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["appointmentdbConnectionString"].ToString();
            conn = new OdbcConnection(connectionString);
            commd = new OdbcCommand("", conn);
            commd2 = new OdbcCommand("", conn);
        }

        public static User LoginUser(string username, string password)
        {
            string query = string.Format("SELECT COUNT(*) FROM tbluser WHERE username ='{0}'", username);
            commd.CommandText = query;
            User user = null;
            try
            {
                conn.Open();
                int amountofUsers = Convert.ToInt32(commd.ExecuteScalar());

                if (amountofUsers == 1)
                {
                    //user exist, check if the password match
                    query = string.Format("SELECT password FROM tbluser WHERE username = '{0}'", username);
                    commd.CommandText = query;
                    string dbPassword = commd.ExecuteScalar().ToString();
                    if (dbPassword == password)
                    {
                        query = string.Format("SELECT username, type FROM tbluser WHERE username = '{0}'", username);
                        commd.CommandText = query;

                        OdbcDataReader reader = commd.ExecuteReader();


                        while (reader.Read())
                        {
                            string email = reader.GetString(0);
                            string type = reader.GetString(1);

                            user = new User(username, password, type);
                        }

                    }
                }
            }
            finally
            {
                conn.Close();
            }
            return user;
        }

        public static string RegisterUser(User user)
        {
            string query = string.Format("SELECT COUNT(*) FROM tbluser WHERE username = '{0}'", user.Username);
            commd.CommandText = query;

            try
            {
                conn.Open();
                int amountOfUsers = Convert.ToInt32(commd.ExecuteScalar());

                if (amountOfUsers < 1)
                {
                    //user does not exist, create a new user
                    query = string.Format("INSERT INTO tbluser (username, password, type) VALUES ('{0}','{1}','{2}')", user.Username, user.Password, user.Type);
                    commd.CommandText = query;
                    commd.ExecuteScalar();
                    return "User registered!";
                }
                else
                {
                    return "A user with this name already exist";
                }
            }
            finally
            {
                conn.Close();
            }
        }

        public static string AddPatient(Pat pat)
        {
            string query = string.Format("SELECT COUNT(*) FROM tblpatient WHERE patient_id = '{0}'", pat.PantientID);
            commd.CommandText = query;
            try
            {
                conn.Open();
                int amountOfUsers = Convert.ToInt32(commd.ExecuteScalar());

                if (amountOfUsers < 1)
                {
                    query = string.Format("INSERT INTO tblpatient (patient_id, fname, lname, gender, age, contact, email, area) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}')", pat.PantientID, pat.Fname, pat.Lname, pat.Gender, pat.Age, pat.Contact, pat.Email, pat.Area);
                    commd.CommandText = query;
                    int count = Convert.ToInt16(commd.ExecuteScalar()) + 1;
                    return "Patient registered!";
                }
                else
                {
                    return "A Patient with this Id already exist";
                }
            }
            finally
            {
                conn.Close();
            }
        }

        public static string AddDoc(Doc doc)
        {
            string query = string.Format("SELECT COUNT(*) FROM tbldoctor WHERE doc_id = '{0}'", doc.DocId);
            commd.CommandText = query;
            try
            {
                conn.Open();
                int amountOfUsers = Convert.ToInt32(commd.ExecuteScalar());

                if (amountOfUsers < 1)
                {
                    query = string.Format("INSERT INTO tbldoctor (doc_id, fname, lname, gender, contact, email, speciality) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}')", doc.DocId, doc.Fname, doc.Lname, doc.Gender, doc.Contact, doc.Email, doc.Speciality);
                    commd.CommandText = query;
                    int count = Convert.ToInt16(commd.ExecuteScalar()) + 1;
                    return "Doctor registered!";
                }
                else
                {
                    return "A Doctor with this Id already exist";
                }
            }
            finally
            {
                conn.Close();
            }
        }
    }
}