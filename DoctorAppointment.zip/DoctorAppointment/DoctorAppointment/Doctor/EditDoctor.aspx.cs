﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace DoctorAppointment.Doctor
{
    public partial class EditDoctor : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblUser.Text = HttpContext.Current.User.Identity.Name;
        }

        protected void grdvwDetails_SelectedIndexChanged(object sender, EventArgs e)
        {
            pnlEdit.Visible = true;
            GridViewRow row = grdvwDetails.SelectedRow;
            txtbxFname.Text = row.Cells[2].Text.ToString();
            txtbxLname.Text = row.Cells[3].Text.ToString();
            txtbxContact.Text = row.Cells[5].Text.ToString();
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to update your details?", "Message from the web", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                dtsrcUpdate.Update();
                MessageBox.Show("Your record was successfully updated.", "Message from the web", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                //do nothing
            }
        }
    }
}