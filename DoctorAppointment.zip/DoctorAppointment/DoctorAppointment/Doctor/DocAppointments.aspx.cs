﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace DoctorAppointment.Doctor
{
    public partial class DocAppointments : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblUser.Text = HttpContext.Current.User.Identity.Name;
        }

        protected void grdvwDocAppointments_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow row = grdvwDocAppointments.SelectedRow;
            txtbxDate.Text = row.Cells[3].Text.ToString();
            txtbxId.Text = row.Cells[4].Text.ToString();

            btnAknowledge.Visible = true;
        }

        protected void btnAknowledge_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to acknowledge the appointment?", "Message from the web", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                dtsrcAppointment.Update();
                MessageBox.Show("Your appointment was aknowledged.", "Message from the web", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                //do nothing
            }
        }
    }
}