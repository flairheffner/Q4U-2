﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace DoctorAppointment.Doctor
{
    public partial class DoctorRegistration : System.Web.UI.Page
    {
        public static string email;
        protected void Page_Load(object sender, EventArgs e)
        {
            email = HttpContext.Current.User.Identity.Name;
            Doc doc = new Doc(txtbxIdNo.Text, txtbxFname.Text, txtbxLname.Text, RadioButtonListGender.SelectedValue, txtbxCell.Text, email, drpdwnSpeciality.SelectedValue);
            txtbxEmail.Text = email;
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            btnRegister.Text = "Adding Details...";
            email = HttpContext.Current.User.Identity.Name;
            Doc doc = new Doc(txtbxIdNo.Text, txtbxFname.Text, txtbxLname.Text, RadioButtonListGender.SelectedValue, txtbxCell.Text, email, drpdwnSpeciality.SelectedValue);
            MessageBox.Show(Connection.AddDoc(doc), "Message from the web", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Response.Redirect("~/Doctor/DoctorHome.aspx");
        }

        protected void txtbxIdNo_TextChanged(object sender, EventArgs e)
        {

            if (Convert.ToInt32(txtbxIdNo.Text.Substring(6, 1)) < 5)
            {
                RadioButtonListGender.SelectedIndex = 0;
            }
            else if (Convert.ToInt32(txtbxIdNo.Text.Substring(6, 1)) > 4)
            {
                RadioButtonListGender.SelectedIndex = 1;
            }
          
        }
    }
}